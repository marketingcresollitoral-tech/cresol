
CREATE TABLE public.agents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agencia text NOT NULL,
  nome text NOT NULL,
  photo_url text,
  aumento_saldo numeric NOT NULL DEFAULT 0,
  meta_aumento_saldo numeric NOT NULL DEFAULT 0,
  producao numeric NOT NULL DEFAULT 0,
  potencial_volume numeric NOT NULL DEFAULT 0,
  leads int NOT NULL DEFAULT 0,
  ordem int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.agents TO anon, authenticated;
GRANT ALL ON public.agents TO service_role;

ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "public read agents" ON public.agents FOR SELECT USING (true);
CREATE POLICY "public write agents" ON public.agents FOR INSERT WITH CHECK (true);
CREATE POLICY "public update agents" ON public.agents FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "public delete agents" ON public.agents FOR DELETE USING (true);

INSERT INTO public.agents (agencia, nome, aumento_saldo, meta_aumento_saldo, producao, potencial_volume, ordem) VALUES
('Jaguaruna', 'Andressa',   70941,    1850000,   -41938,   6740000,  1),
('Jaguaruna', 'Janice',     1082494,  1790000,   26759,    5800000,  2),
('Jaguaruna', 'Rodrigo',    78488,    1700000,   175025,   4980000,  3),
('Sangao',    'André',      1626530,  2508244,   174263,   12898000, 1),
('Sangao',    'Alcineia',   4625983,  1850000,   26519,    8400000,  2),
('Sangao',    'Laís',       -103041,  1000000,   -73567,   3100000,  3),
('Sangao',    'Filipe',     881793,   1568207,   987264,   6427000,  4),
('Paulo Lopes','Daiane',    -12091,   1560000,   37584,    3600000,  1),
('Paulo Lopes','Luana',     345480,   1000000,   -13381,   2200000,  2),
('Paulo Lopes','Francine',  1121036,  800000,    11402,    5794000,  3),
('Içara',     'Regiane',    1645741,  1780000,   -6,       6060000,  1),
('Içara',     'Maiara',     1962001,  2000000,   -92228,   8080000,  2),
('Içara',     'Adenilson',  -113780,  1800000,   -119438,  14200000, 3),
('Tubarão',   'Denise/PF',  1150492,  1560000,   67513,    3780000,  1),
('Tubarão',   'Juliano/Agro',141371,  280000,    -7592,    280000,   2),
('Tubarão',   'Juliano/PJ', 1434738,  520000,    -1764,    11000000, 3),
('Laguna',    'Renata',     1543657,  1560000,   -46427,   3740000,  1),
('Laguna',    'Charllie',   746537,   1295132,   44416,    2279000,  2);
