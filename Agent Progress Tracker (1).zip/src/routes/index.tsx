import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { Suspense, useState } from "react";
import { Toaster } from "sonner";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  fetchAgents,
  groupByAgency,
  pctMeta,
  pctVolume,
  pctLeads,
  seloOf,
  seloPontos,
  
  fmtBRL,
  type Agent,
} from "@/lib/agents";
import { AgentTimeline } from "@/components/AgentTimeline";
import { AgentEditDialog } from "@/components/AgentEditDialog";
import { MissionLogo, MissionTimers, GlitchOverlay } from "@/components/MissionChrome";

const agentsQuery = queryOptions({
  queryKey: ["agents"],
  queryFn: fetchAgents,
  staleTime: 10_000,
});

export const Route = createFileRoute("/")({
  loader: ({ context }) => context.queryClient.ensureQueryData(agentsQuery),
  component: Index,
  errorComponent: ({ error }) => (
    <div className="min-h-screen bg-neutral-950 text-white flex items-center justify-center p-8">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-bold mb-2">Erro ao carregar painel</h1>
        <p className="text-white/60 text-sm">{error.message}</p>
      </div>
    </div>
  ),
});

function Index() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-neutral-950" />}>
      <Dashboard />
      <Toaster theme="dark" richColors />
    </Suspense>
  );
}

function Dashboard() {
  const { data: agents } = useSuspenseQuery(agentsQuery);
  const agencies = groupByAgency(agents);
  const [editing, setEditing] = useState<Agent | null>(null);

  const totalProducao = sum(agents, (a) => a.producao);
  const totalMeta = sum(agents, (a) => a.meta_aumento_saldo);
  const totalLeads = sum(agents, (a) => a.leads);
  const totalLeadsRecebidos = sum(agents, (a) => a.leads_total);
  const totalPotencial = sum(agents, (a) => a.potencial_volume);
  const globalPctMeta = totalMeta ? (totalProducao / totalMeta) * 100 : 0;
  const globalPctVolume = totalPotencial ? (totalProducao / totalPotencial) * 100 : 0;
  const globalPctLeads = totalLeadsRecebidos ? (totalLeads / totalLeadsRecebidos) * 100 : 0;
  const totalSelos = agents.reduce((acc, a) => acc + seloPontos(a), 0);

  return (
    <div className="relative min-h-screen bg-[radial-gradient(ellipse_at_top,#1a1a2e_0%,#0a0a0f_60%)] text-white overflow-hidden">
      <GlitchOverlay />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 py-8 sm:py-12 space-y-10 z-[1]">
        {/* HERO */}
        <header>
          <div className="flex items-center justify-center gap-3 text-[10px] uppercase tracking-[0.35em] text-orange-400 mb-4">
            <span className="inline-block w-8 h-px bg-orange-400" />
            X7-MISS-16 // CLASSIFIED
            <span className="inline-block w-8 h-px bg-orange-400" />
          </div>

          <MissionLogo />
          <MissionTimers />


          <div className="mt-8 rounded-2xl border border-orange-500/30 bg-gradient-to-br from-orange-500/10 to-transparent p-6 sm:p-8">
            <div className="grid gap-6 sm:grid-cols-4">
              <MetricBig
                label="Atingimento Geral"
                value={`${globalPctMeta.toFixed(1).replace(".", ",")}%`}
                sub={`${fmtBRL(totalProducao)} / ${fmtBRL(totalMeta)}`}
                accent="orange"
              />
              <MetricBig
                label="Leads Convertidos"
                value={`${globalPctLeads.toFixed(1).replace(".", ",")}%`}
                sub={`${totalLeads} / ${totalLeadsRecebidos} recebidos`}
                accent="emerald"
              />
              <MetricBig
                label="Volume Captado"
                value={`${globalPctVolume.toFixed(1).replace(".", ",")}%`}
                sub={`${fmtBRL(totalProducao)} / ${fmtBRL(totalPotencial)}`}
                accent="blue"
              />
              <MetricBig
                label="Selos (pts)"
                value={String(totalSelos)}
                sub={`${agencies.length} agências · ${agents.length} agentes`}
                accent="white"
              />
            </div>

            {/* LINHA DO TEMPO GERAL com avatares */}
            <div className="mt-8">
              <div className="flex items-center justify-between text-[10px] uppercase tracking-widest text-white/50 mb-2">
                <span>Linha do tempo — Meta geral</span>
                <span>{globalPctMeta.toFixed(1).replace(".", ",")}%</span>
              </div>
              <GlobalRace agents={agents} onPick={setEditing} />
              <div className="flex justify-between text-[9px] uppercase tracking-wider text-white/30 mt-1">
                <span>0%</span>
                <span>50%</span>
                <span>100%</span>
              </div>
            </div>
          </div>
        </header>

        <section className="space-y-8">
          {agencies.map(({ agencia, agents: ags }) => (
            <AgencyBlock key={agencia} agencia={agencia} agents={ags} />
          ))}
        </section>

        <footer className="text-center text-[10px] uppercase tracking-widest text-white/30 pt-8 pb-4">
          Missão 16 — Painel Cooperativa · Confidencial
        </footer>
      </div>

      {editing && <AgentEditDialog agent={editing} onClose={() => setEditing(null)} />}
    </div>
  );
}

function GlobalRace({ agents, onPick }: { agents: Agent[]; onPick: (a: Agent) => void }) {
  // ordenados por %; lanes atribuídos por colisão (evita sobreposição no mesmo X)
  const sorted = [...agents].sort((a, b) => pctMeta(a) - pctMeta(b));
  const avgPct = Math.max(0, Math.min(100, avg(agents.map(pctMeta))));

  const LANES = 6;
  const LANE_TOP = [16, 76, 136, 196, 256, 316];
  const CONTAINER_H = 460;
  const TRACK_BOTTOM = 44;
  const AVATAR_BLOCK = 60;
  const MIN_GAP_PCT = 7;

  const laneLast: number[] = new Array(LANES).fill(-999);
  const placement = sorted.map((a) => {
    const p = Math.max(0, Math.min(100, pctMeta(a)));
    let chosen = 0;
    for (let i = 0; i < LANES; i++) {
      if (p - laneLast[i] >= MIN_GAP_PCT) { chosen = i; break; }
      if (i === LANES - 1) chosen = laneLast.indexOf(Math.min(...laneLast));
    }
    laneLast[chosen] = p;
    return { agent: a, p, lane: chosen };
  });

  const trackFromTop = CONTAINER_H - TRACK_BOTTOM - 4;

  return (
    <>
      <div
        className="relative rounded-xl bg-white/5 px-3 group/race overflow-visible"
        style={{ height: CONTAINER_H }}
      >
        {[0, 25, 50, 75, 100].map((m) => (
          <div
            key={m}
            className="absolute inset-y-0 w-px bg-white/10"
            style={{ left: `calc(12px + (100% - 24px) * ${m} / 100)` }}
          />
        ))}
        {LANE_TOP.map((t, i) => (
          <span key={i} className="absolute left-1 text-[8px] font-mono uppercase tracking-widest text-white/25" style={{ top: t + 4 }}>
            L{i + 1}
          </span>
        ))}

        <div className="absolute inset-x-3 h-4 rounded-full bg-white/10" style={{ bottom: TRACK_BOTTOM }} />
        <div
          className="absolute left-3 h-4 rounded-full bg-gradient-to-r from-orange-500 via-red-500 to-red-600 shadow-[0_0_25px_rgba(249,115,22,0.5)]"
          style={{ bottom: TRACK_BOTTOM, width: `calc((100% - 24px) * ${avgPct} / 100)` }}
        />

        <div
          className="absolute w-0.5 bg-emerald-400/70 shadow-[0_0_10px_rgba(52,211,153,0.6)]"
          style={{ left: `calc(100% - 12px)`, top: 8, bottom: TRACK_BOTTOM - 4 }}
        />
        <div className="absolute text-[9px] font-bold text-emerald-400 uppercase tracking-widest" style={{ right: 4, bottom: TRACK_BOTTOM + 20 }}>
          Meta
        </div>

        {placement.map(({ agent: a, p, lane }) => {
          const done = pctMeta(a) >= 100;
          const topPx = LANE_TOP[lane];
          const connectorH = trackFromTop - topPx - AVATAR_BLOCK;
          return (
            <button
              key={a.id}
              onClick={() => onPick(a)}
              className="absolute -translate-x-1/2 group flex flex-col items-center z-10 hover:z-50 focus:z-50 cursor-pointer"
              style={{ left: `calc(12px + (100% - 24px) * ${p} / 100)`, top: topPx }}
              title={`${a.nome} — ${pctMeta(a).toFixed(1)}%`}
            >
              <span className={`text-[10px] font-bold tabular-nums leading-none mb-1 px-1.5 py-0.5 rounded ${done ? "bg-emerald-500/20 text-emerald-300" : "bg-white/10 text-white/90"}`}>
                {pctMeta(a).toFixed(1).replace(".", ",")}%
              </span>
              <Avatar className={`h-14 w-14 border-2 transition-all duration-200 group-hover:scale-[1.5] group-hover:shadow-[0_0_28px_rgba(255,255,255,0.55)] group-focus:scale-[1.5] group-hover/race:opacity-40 group-hover:!opacity-100 ${done ? "border-emerald-400 shadow-[0_0_14px_rgba(52,211,153,0.7)]" : "border-white/70 group-hover:border-orange-400"}`}>
                <AvatarImage src={a.photo_url ?? undefined} alt={a.nome} />
                <AvatarFallback className="bg-white/10 text-white text-[11px]">
                  {a.nome.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <span className="text-[10px] text-white/70 leading-none mt-1 max-w-[80px] truncate group-hover:text-white font-medium">{a.nome.split(" ")[0]}</span>
              <span
                className={`w-px mt-1 ${done ? "bg-emerald-400/70" : "bg-white/40"} group-hover:bg-white/80`}
                style={{ height: Math.max(0, connectorH - 12) }}
              />
              <span className={`w-2.5 h-2.5 rounded-full ring-2 ring-black/60 ${done ? "bg-emerald-400" : "bg-white"} group-hover:scale-150 transition-transform`} />

              <div
                className="pointer-events-none absolute opacity-0 group-hover:opacity-100 group-focus:opacity-100 transition-opacity duration-150 -translate-x-1/2 left-1/2 top-full mt-2 w-60 rounded-lg border border-white/15 bg-neutral-900/95 backdrop-blur-sm shadow-2xl p-3 text-left"
                style={{ zIndex: 60 }}
              >
                <div className="text-[11px] font-bold text-white truncate">{a.nome}</div>
                <div className="text-[9px] uppercase tracking-wider text-white/50 mb-2">{a.agencia}</div>
                <div className="space-y-1 text-[10px] text-white/80">
                  <div className="flex justify-between"><span className="text-white/50">% Meta</span><span className="font-bold tabular-nums text-orange-300">{pctMeta(a).toFixed(1).replace(".", ",")}%</span></div>
                  <div className="flex justify-between"><span className="text-white/50">Produção</span><span className="tabular-nums">{fmtBRL(a.producao)}</span></div>
                  <div className="flex justify-between"><span className="text-white/50">Meta</span><span className="tabular-nums">{fmtBRL(a.meta_aumento_saldo)}</span></div>
                  <div className="flex justify-between"><span className="text-white/50">Leads</span><span className="tabular-nums">{a.leads}/{a.leads_total}</span></div>
                  <div className="flex justify-between"><span className="text-white/50">Selos</span><span className="tabular-nums">🟢{a.selos_verde ?? 0} 🔵{a.selos_azul ?? 0} 🔴{a.selos_vermelho ?? 0} · {seloPontos(a)}pt</span></div>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Leaderboard clicável — atalho pra editar sem mirar na bolinha */}
      <div className="mt-3">
        <div className="text-[9px] uppercase tracking-[0.28em] text-white/40 mb-2">Roster · clique para editar</div>
        <div className="flex flex-wrap gap-1.5">
          {[...agents].sort((a, b) => pctMeta(b) - pctMeta(a)).map((a) => {
            const p = pctMeta(a);
            const done = p >= 100;
            return (
              <button
                key={a.id}
                onClick={() => onPick(a)}
                className={`group flex items-center gap-2 rounded-full border pl-1 pr-3 py-1 transition-all hover:scale-105 ${done ? "border-emerald-400/60 bg-emerald-500/10" : "border-white/15 bg-white/5 hover:border-orange-400/60 hover:bg-orange-500/10"}`}
              >
                <Avatar className="h-6 w-6 border border-white/30">
                  <AvatarImage src={a.photo_url ?? undefined} alt={a.nome} />
                  <AvatarFallback className="bg-white/10 text-white text-[8px]">
                    {a.nome.slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <span className="text-[10px] text-white/80 group-hover:text-white font-medium">{a.nome.split(" ")[0]}</span>
                <span className={`text-[10px] font-bold tabular-nums ${done ? "text-emerald-300" : "text-orange-300"}`}>
                  {p.toFixed(1).replace(".", ",")}%
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </>
  );
}

function AgencyBlock({ agencia, agents }: { agencia: string; agents: Agent[] }) {
  const producaoAg = sum(agents, (a) => a.producao);
  const metaAg = sum(agents, (a) => a.meta_aumento_saldo);
  const potencialAg = sum(agents, (a) => a.potencial_volume);
  const leadsAg = sum(agents, (a) => a.leads);
  const leadsRecAg = sum(agents, (a) => a.leads_total);

  const pctMetaAg = metaAg ? (producaoAg / metaAg) * 100 : 0;
  const pctVolumeAg = potencialAg ? (producaoAg / potencialAg) * 100 : 0;
  const pctLeadsAg = leadsRecAg ? (leadsAg / leadsRecAg) * 100 : 0;

  const totalSeloPts = agents.reduce((acc, a) => acc + seloPontos(a), 0);
  const counts = {
    verde: sum(agents, (a) => a.selos_verde ?? 0),
    azul: sum(agents, (a) => a.selos_azul ?? 0),
    vermelho: sum(agents, (a) => a.selos_vermelho ?? 0),
  };

  return (
    <div className="rounded-2xl border border-white/10 bg-neutral-900/50 backdrop-blur p-6 sm:p-8">
      <div className="flex items-baseline justify-between flex-wrap gap-2 mb-4">
        <div>
          <div className="text-[10px] uppercase tracking-[0.3em] text-orange-400/80">Agência</div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">{agencia}</h2>
        </div>
        <div className="text-right text-xs text-white/60">
          {agents.length} agentes · {leadsAg}/{leadsRecAg} leads · {fmtBRL(producaoAg)}
        </div>
      </div>

      {/* SCORE BOARD por agência */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
        <ScoreCard
          label="01 · Meta Saldo"
          value={`${pctMetaAg.toFixed(1).replace(".", ",")}%`}
          sub={`${fmtBRL(producaoAg)} / ${fmtBRL(metaAg)}`}
          accent="orange"
        />
        <ScoreCard
          label="02 · Leads"
          value={`${pctLeadsAg.toFixed(1).replace(".", ",")}%`}
          sub={`${leadsAg} de ${leadsRecAg} convertidos`}
          accent="emerald"
        />
        <SelosScoreCard
          totalPts={totalSeloPts}
          verde={counts.verde}
          azul={counts.azul}
          vermelho={counts.vermelho}
        />
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <AgentTimeline
          title="01 · % Meta Aumento de Saldo"
          accent="meta"
          items={agents.map((a) => ({
            agent: a,
            pct: pctMeta(a),
            labelSecondary: fmtBRL(a.producao),
          }))}
          totalLabel="Total agência"
          totalPct={pctMetaAg}
          totalSecondary={`${fmtBRL(producaoAg)} / ${fmtBRL(metaAg)}`}
        />
        <AgentTimeline
          title="02 · Leads Convertidos"
          accent="leads"
          items={agents.map((a) => ({
            agent: a,
            pct: pctLeads(a),
            labelSecondary: `${a.leads}/${a.leads_total}`,
          }))}
          totalLabel="Total agência"
          totalPct={pctLeadsAg}
          totalSecondary={`${leadsAg}/${leadsRecAg}`}
        />
        <AgentTimeline
          title="03 · Volume Captado · Selos"
          accent="volume"
          items={agents.map((a) => {
            const s = seloOf(a);
            const pts = seloPontos(a);
            const parts: string[] = [];
            if (a.selos_verde) parts.push(`🟢${a.selos_verde}`);
            if (a.selos_azul) parts.push(`🔵${a.selos_azul}`);
            if (a.selos_vermelho) parts.push(`🔴${a.selos_vermelho}`);
            return {
              agent: a,
              pct: pctVolume(a),
              labelSecondary: parts.length ? `${parts.join(" ")} · ${pts}pt` : "sem selos",
              badge: s.selo ?? undefined,
            };
          })}
          totalLabel="Selos agência"
          totalPct={pctVolumeAg}
          totalSecondary={`${totalSeloPts} pts`}
        />
      </div>
    </div>
  );
}

function ScoreCard({
  label,
  value,
  sub,
  accent,
}: {
  label: string;
  value: string;
  sub: string;
  accent: "orange" | "emerald" | "blue";
}) {
  const map = {
    orange: "border-orange-500/30 bg-orange-500/5 text-orange-300",
    emerald: "border-emerald-500/30 bg-emerald-500/5 text-emerald-300",
    blue: "border-blue-500/30 bg-blue-500/5 text-cyan-300",
  }[accent];
  return (
    <div className={`rounded-xl border p-4 ${map}`}>
      <div className="text-[10px] uppercase tracking-widest text-white/60">{label}</div>
      <div className="text-2xl font-black tabular-nums mt-1">{value}</div>
      <div className="text-[11px] text-white/50 mt-0.5">{sub}</div>
    </div>
  );
}

function SelosScoreCard({
  totalPts,
  verde,
  azul,
  vermelho,
}: {
  totalPts: number;
  verde: number;
  azul: number;
  vermelho: number;
}) {
  const chips = [
    { n: verde, label: "V", pts: 5, from: "from-emerald-400", to: "to-emerald-600", ring: "ring-emerald-400/70", glow: "shadow-[0_0_22px_rgba(52,211,153,0.85)]", text: "text-emerald-300", hex: "#10b981" },
    { n: azul, label: "A", pts: 3, from: "from-blue-400", to: "to-blue-600", ring: "ring-blue-400/70", glow: "shadow-[0_0_22px_rgba(59,130,246,0.85)]", text: "text-blue-300", hex: "#3b82f6" },
    { n: vermelho, label: "R", pts: 1, from: "from-red-400", to: "to-red-600", ring: "ring-red-400/70", glow: "shadow-[0_0_22px_rgba(239,68,68,0.9)]", text: "text-red-300", hex: "#ef4444" },
  ];
  return (
    <div className="relative rounded-xl border border-cyan-500/30 bg-gradient-to-br from-cyan-500/5 via-blue-500/5 to-transparent p-4 overflow-hidden">
      {/* HUD lines */}
      <span className="pointer-events-none absolute -top-px -left-px h-4 w-4 border-t-2 border-l-2 border-cyan-400/70" />
      <span className="pointer-events-none absolute -top-px -right-px h-4 w-4 border-t-2 border-r-2 border-cyan-400/70" />
      <span className="pointer-events-none absolute -bottom-px -left-px h-4 w-4 border-b-2 border-l-2 border-cyan-400/70" />
      <span className="pointer-events-none absolute -bottom-px -right-px h-4 w-4 border-b-2 border-r-2 border-cyan-400/70" />

      <div className="flex items-center justify-between mb-2">
        <div className="text-[10px] uppercase tracking-widest text-cyan-300/80">03 · Selos Volume</div>
        <span className="text-[9px] font-mono text-cyan-400/70 m16-blip">◉ REC</span>
      </div>
      <div className="flex items-baseline gap-2 mb-3">
        <div className="text-3xl sm:text-4xl font-black tabular-nums text-white leading-none">{totalPts}</div>
        <div className="text-[10px] uppercase tracking-[0.25em] text-cyan-300/70">pts</div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {chips.map((c) => (
          <div
            key={c.label}
            className={`relative rounded-lg border border-white/10 bg-black/50 backdrop-blur px-2 py-2 flex flex-col items-center ${c.n > 0 ? c.glow : ""}`}
          >
            {/* selo circular tech */}
            <div className="relative mb-1">
              <span className={`absolute inset-0 rounded-full ring-2 ${c.ring} ${c.n > 0 ? "animate-ping" : "opacity-30"}`} />
              <div
                className={`relative h-12 w-12 rounded-full bg-gradient-to-br ${c.from} ${c.to} flex items-center justify-center text-white font-black text-xl tabular-nums shadow-inner`}
                style={{ boxShadow: `inset 0 0 0 2px rgba(0,0,0,0.35), 0 0 18px ${c.hex}55` }}
              >
                {c.n}
              </div>
              {/* marcadores em cruz estilo alvo */}
              <span className="absolute inset-0 pointer-events-none rounded-full">
                <span className="absolute left-1/2 -top-1 w-px h-1.5 bg-white/60 -translate-x-1/2" />
                <span className="absolute left-1/2 -bottom-1 w-px h-1.5 bg-white/60 -translate-x-1/2" />
                <span className="absolute top-1/2 -left-1 h-px w-1.5 bg-white/60 -translate-y-1/2" />
                <span className="absolute top-1/2 -right-1 h-px w-1.5 bg-white/60 -translate-y-1/2" />
              </span>
            </div>
            <div className={`text-[9px] font-mono uppercase tracking-widest ${c.text}`}>{c.label} · {c.pts}pt</div>
            <div className="text-[10px] tabular-nums text-white/60">= {c.n * c.pts}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function MetricBig({
  label,
  value,
  sub,
  accent,
}: {
  label: string;
  value: string;
  sub: string;
  accent: "orange" | "emerald" | "blue" | "white";
}) {
  const color = {
    orange: "text-orange-400",
    emerald: "text-emerald-400",
    blue: "text-cyan-400",
    white: "text-white",
  }[accent];
  return (
    <div>
      <div className="text-[10px] uppercase tracking-[0.25em] text-white/50">{label}</div>
      <div className={`mt-1 text-3xl sm:text-4xl font-black tabular-nums ${color}`}>{value}</div>
      <div className="mt-1 text-[11px] text-white/50">{sub}</div>
    </div>
  );
}

function sum<T>(arr: T[], sel: (x: T) => number) {
  return arr.reduce((acc, x) => acc + sel(x), 0);
}

function avg(arr: number[]) {
  if (!arr.length) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}
