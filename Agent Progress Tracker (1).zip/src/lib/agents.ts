import { supabase } from "@/integrations/supabase/client";

export type Agent = {
  id: string;
  agencia: string;
  nome: string;
  photo_url: string | null;
  aumento_saldo: number;
  meta_aumento_saldo: number;
  producao: number;
  potencial_volume: number;
  leads: number;
  leads_total: number;
  cdi_percent: number;
  selos_verde: number;
  selos_azul: number;
  selos_vermelho: number;
  ordem: number;
};

export const AGENCY_ORDER = [
  "Jaguaruna",
  "Sangao",
  "Paulo Lopes",
  "Içara",
  "Tubarão",
  "Laguna",
];

export async function fetchAgents(): Promise<Agent[]> {
  const { data, error } = await supabase
    .from("agents")
    .select("*")
    .order("agencia")
    .order("ordem");
  if (error) throw error;
  return (data ?? []) as Agent[];
}

export async function updateAgent(id: string, patch: Partial<Agent>) {
  const { error } = await supabase.from("agents").update(patch).eq("id", id);
  if (error) throw error;
}

export function pctMeta(a: Agent) {
  if (!a.meta_aumento_saldo) return 0;
  return (a.producao / a.meta_aumento_saldo) * 100;
}

export function pctVolume(a: Agent) {
  if (!a.potencial_volume) return 0;
  return (a.producao / a.potencial_volume) * 100;
}

export function pctLeads(a: Agent) {
  if (!a.leads_total) return 0;
  return (a.leads / a.leads_total) * 100;
}

/** Selos agora são acumulados manualmente:
 *  Verde  = 5 pts cada
 *  Azul   = 3 pts cada
 *  Vermelho = 1 pt cada
 *  Total do agente = verde*5 + azul*3 + vermelho*1 */
export type Selo = "verde" | "azul" | "vermelho" | null;

export const SELO_PTS = { verde: 5, azul: 3, vermelho: 1 } as const;

export function seloPontos(a: Agent): number {
  return (
    (a.selos_verde ?? 0) * SELO_PTS.verde +
    (a.selos_azul ?? 0) * SELO_PTS.azul +
    (a.selos_vermelho ?? 0) * SELO_PTS.vermelho
  );
}

export function seloTotalCount(a: Agent): number {
  return (a.selos_verde ?? 0) + (a.selos_azul ?? 0) + (a.selos_vermelho ?? 0);
}

/** Selo "dominante" do agente (o de maior contagem), pra exibir badge de destaque. */
export function seloOf(a: Agent): { selo: Selo; pontos: number } {
  const pontos = seloPontos(a);
  const v = a.selos_verde ?? 0;
  const az = a.selos_azul ?? 0;
  const vm = a.selos_vermelho ?? 0;
  if (v === 0 && az === 0 && vm === 0) return { selo: null, pontos: 0 };
  let selo: Selo = "verde";
  let max = v;
  if (az > max) { selo = "azul"; max = az; }
  if (vm > max) { selo = "vermelho"; max = vm; }
  return { selo, pontos };
}

export const SELO_META = {
  verde: { label: "Verde", cls: "bg-emerald-500/20 text-emerald-300 border-emerald-500/40", dot: "bg-emerald-400" },
  azul: { label: "Azul", cls: "bg-blue-500/20 text-blue-300 border-blue-500/40", dot: "bg-blue-400" },
  vermelho: { label: "Vermelho", cls: "bg-red-500/20 text-red-300 border-red-500/40", dot: "bg-red-400" },
} as const;

export function fmtBRL(n: number) {
  return n.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
    maximumFractionDigits: 0,
  });
}

export function fmtPct(n: number) {
  return `${n.toFixed(1).replace(".", ",")}%`;
}

export function groupByAgency(list: Agent[]) {
  const map = new Map<string, Agent[]>();
  for (const a of list) {
    if (!map.has(a.agencia)) map.set(a.agencia, []);
    map.get(a.agencia)!.push(a);
  }
  return AGENCY_ORDER
    .filter((ag) => map.has(ag))
    .map((ag) => ({ agencia: ag, agents: map.get(ag)! }));
}
