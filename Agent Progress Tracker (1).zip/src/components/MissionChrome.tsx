import { useEffect, useRef, useState } from "react";
import logoAsset from "@/assets/missao16-logo.png.asset.json";

const DEFAULT_START = "2026-07-13T00:00";
const DEFAULT_END = "2026-08-13T23:59";
const LS_START = "m16.mission.start";
const LS_END = "m16.mission.end";

function pad(n: number, size = 2) {
  return String(Math.max(0, Math.floor(n))).padStart(size, "0");
}

function useNow(intervalMs = 1000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}

/** hidrata datas do localStorage no cliente (evita mismatch de SSR). */
function useMissionDates() {
  const [start, setStart] = useState<string>(DEFAULT_START);
  const [end, setEnd] = useState<string>(DEFAULT_END);
  useEffect(() => {
    try {
      const s = localStorage.getItem(LS_START);
      const e = localStorage.getItem(LS_END);
      if (s) setStart(s);
      if (e) setEnd(e);
    } catch {}
  }, []);
  const saveStart = (v: string) => {
    setStart(v);
    try { localStorage.setItem(LS_START, v); } catch {}
  };
  const saveEnd = (v: string) => {
    setEnd(v);
    try { localStorage.setItem(LS_END, v); } catch {}
  };
  return { start, end, saveStart, saveEnd };
}

export function MissionLogo() {
  return (
    <div className="flex justify-center">
      <div className="relative">
        <img
          src={logoAsset.url}
          alt="Missão 16"
          className="h-40 sm:h-56 md:h-64 w-auto drop-shadow-[0_0_40px_rgba(249,115,22,0.35)] m16-glitch"
        />
        <span className="pointer-events-none absolute -top-2 -left-2 h-6 w-6 border-t-2 border-l-2 border-orange-500/80" />
        <span className="pointer-events-none absolute -top-2 -right-2 h-6 w-6 border-t-2 border-r-2 border-orange-500/80" />
        <span className="pointer-events-none absolute -bottom-2 -left-2 h-6 w-6 border-b-2 border-l-2 border-orange-500/80" />
        <span className="pointer-events-none absolute -bottom-2 -right-2 h-6 w-6 border-b-2 border-r-2 border-orange-500/80" />
      </div>
    </div>
  );
}

export function MissionTimers() {
  const now = useNow(1000);
  const { start, end, saveStart, saveEnd } = useMissionDates();
  const startMs = new Date(start).getTime();
  const endMs = new Date(end).getTime();

  const remainingMs = Math.max(0, endMs - now);
  const elapsedMs = Math.max(0, now - startMs);
  const totalMs = Math.max(1, endMs - startMs);
  const progressPct = Math.max(0, Math.min(100, (elapsedMs / totalMs) * 100));

  const days = Math.floor(remainingMs / 86_400_000);
  const hours = Math.floor((remainingMs % 86_400_000) / 3_600_000);
  const mins = Math.floor((remainingMs % 3_600_000) / 60_000);
  const secs = Math.floor((remainingMs % 60_000) / 1000);

  const eD = Math.floor(elapsedMs / 86_400_000);
  const eH = Math.floor((elapsedMs % 86_400_000) / 3_600_000);
  const eM = Math.floor((elapsedMs % 3_600_000) / 60_000);
  const eS = Math.floor((elapsedMs % 60_000) / 1000);

  return (
    <div className="mt-6 space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <TimerCard
          label="T-Minus · fim da missão"
          tone="orange"
          dateValue={end}
          onDateChange={saveEnd}
          segments={[
            { v: pad(days, 2), l: "dias" },
            { v: pad(hours), l: "hr" },
            { v: pad(mins), l: "min" },
            { v: pad(secs), l: "seg" },
          ]}
        />
        <TimerCard
          label="Tempo em campo"
          tone="emerald"
          dateValue={start}
          onDateChange={saveStart}
          segments={[
            { v: pad(eD, 2), l: "dias" },
            { v: pad(eH), l: "hr" },
            { v: pad(eM), l: "min" },
            { v: pad(eS), l: "seg" },
          ]}
        />
      </div>
      <div className="rounded-lg border border-white/10 bg-black/40 px-3 py-2">
        <div className="flex items-center justify-between text-[9px] uppercase tracking-[0.28em] text-white/50 mb-1">
          <span>Progresso da janela da missão</span>
          <span className="font-mono text-orange-300">{progressPct.toFixed(1).replace(".", ",")}%</span>
        </div>
        <div className="relative h-1.5 bg-white/5 rounded-full overflow-hidden">
          <div
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-emerald-500 via-orange-500 to-red-600"
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </div>
    </div>
  );
}

function TimerCard({
  label,
  segments,
  tone,
  dateValue,
  onDateChange,
}: {
  label: string;
  segments: { v: string; l: string }[];
  tone: "orange" | "emerald";
  dateValue: string;
  onDateChange: (v: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const toneCls =
    tone === "orange"
      ? "border-orange-500/40 shadow-[0_0_30px_rgba(249,115,22,0.15)]"
      : "border-emerald-500/40 shadow-[0_0_30px_rgba(52,211,153,0.12)]";
  const dotCls = tone === "orange" ? "text-orange-400" : "text-emerald-400";
  const humanDate = dateValue ? new Date(dateValue).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" }) : "—";

  useEffect(() => {
    if (editing) inputRef.current?.focus();
  }, [editing]);

  return (
    <div className={`relative rounded-xl border bg-black/50 backdrop-blur px-4 py-3 ${toneCls}`}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className={`inline-block h-2 w-2 rounded-full bg-current m16-pulse-dot ${dotCls}`} />
          <span className="text-[10px] uppercase tracking-[0.28em] text-white/60">{label}</span>
        </div>
        <button
          type="button"
          onClick={() => setEditing((v) => !v)}
          className="text-[9px] font-mono uppercase tracking-widest text-white/50 hover:text-white transition-colors border border-white/10 hover:border-white/40 rounded px-1.5 py-0.5"
          title="Clique para editar a data"
        >
          {humanDate} · editar
        </button>
      </div>
      {editing && (
        <div className="mb-2 flex items-center gap-2">
          <input
            ref={inputRef}
            type="datetime-local"
            value={dateValue}
            onChange={(e) => onDateChange(e.target.value)}
            className="flex-1 bg-black/60 border border-white/20 rounded px-2 py-1 text-[11px] text-white font-mono focus:outline-none focus:border-orange-400"
          />
          <button
            onClick={() => setEditing(false)}
            className="text-[10px] uppercase tracking-widest text-white/70 hover:text-white border border-white/20 rounded px-2 py-1"
          >
            OK
          </button>
        </div>
      )}
      <div className="flex items-baseline gap-1 font-mono tabular-nums">
        {segments.map((s, i) => (
          <div key={i} className="flex items-baseline">
            <span className="text-2xl sm:text-3xl font-black text-white leading-none">{s.v}</span>
            <span className="ml-1 text-[9px] uppercase text-white/40">{s.l}</span>
            {i < segments.length - 1 && <span className="mx-1 text-white/30">:</span>}
          </div>
        ))}
      </div>
    </div>
  );
}

/** Overlay de glitch: scanlines, ruído e flashes aleatórios pela página. */
export function GlitchOverlay() {
  const [burst, setBurst] = useState(false);
  useEffect(() => {
    let alive = true;
    let t: ReturnType<typeof setTimeout>;
    function loop() {
      if (!alive) return;
      const wait = 4000 + Math.random() * 12000;
      t = setTimeout(() => {
        if (!alive) return;
        setBurst(true);
        setTimeout(() => setBurst(false), 180 + Math.random() * 260);
        loop();
      }, wait);
    }
    loop();
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, []);

  return (
    <>
      <div className="m16-noise" aria-hidden />
      <div className="m16-scanbar" aria-hidden />
      <div className="m16-flicker" aria-hidden />
      {burst && (
        <div
          aria-hidden
          className="fixed inset-0 pointer-events-none z-[42]"
          style={{
            background:
              "linear-gradient(90deg, rgba(255,0,77,0.06), rgba(0,230,255,0.06))",
            mixBlendMode: "screen",
            transform: `translateX(${(Math.random() - 0.5) * 6}px)`,
          }}
        />
      )}
    </>
  );
}
