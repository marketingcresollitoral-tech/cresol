import { useState } from "react";
import { Bomb } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { AgentEditDialog } from "./AgentEditDialog";
import { SELO_PTS, type Agent, type Selo } from "@/lib/agents";

function SeloBadge({ selo, verde, azul, vermelho }: { selo: Selo; verde: number; azul: number; vermelho: number }) {
  const total = verde * SELO_PTS.verde + azul * SELO_PTS.azul + vermelho * SELO_PTS.vermelho;
  const tone =
    selo === "verde"
      ? { ring: "ring-emerald-400/60", glow: "shadow-[0_0_18px_rgba(52,211,153,0.65)]", text: "text-emerald-300", border: "border-emerald-400/50", bg: "bg-emerald-500/10" }
      : selo === "azul"
      ? { ring: "ring-blue-400/60", glow: "shadow-[0_0_18px_rgba(59,130,246,0.65)]", text: "text-blue-300", border: "border-blue-400/50", bg: "bg-blue-500/10" }
      : { ring: "ring-red-400/60", glow: "shadow-[0_0_18px_rgba(239,68,68,0.7)]", text: "text-red-300", border: "border-red-400/50", bg: "bg-red-500/10" };

  return (
    <span className={`relative inline-flex items-center gap-2 border rounded-lg px-2.5 py-1 ${tone.border} ${tone.bg} ${tone.glow}`}>
      <span className={`absolute inset-0 rounded-lg ring-2 ${tone.ring} animate-pulse pointer-events-none`} />
      <Bomb className={`h-4 w-4 ${tone.text} m16-pulse-dot`} strokeWidth={2.5} />
      <span className="flex items-center gap-1">
        {verde > 0 && <span className="inline-flex items-center gap-0.5 text-[11px] font-black text-emerald-300"><span className="w-3 h-3 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.9)] animate-pulse" />{verde}</span>}
        {azul > 0 && <span className="inline-flex items-center gap-0.5 text-[11px] font-black text-blue-300"><span className="w-3 h-3 rounded-full bg-blue-400 shadow-[0_0_10px_rgba(59,130,246,0.9)] animate-pulse" />{azul}</span>}
        {vermelho > 0 && <span className="inline-flex items-center gap-0.5 text-[11px] font-black text-red-300"><span className="w-3 h-3 rounded-full bg-red-400 shadow-[0_0_10px_rgba(239,68,68,0.9)] animate-pulse" />{vermelho}</span>}
      </span>
      <span className={`text-[10px] font-black uppercase tracking-widest ${tone.text} tabular-nums border-l ${tone.border} pl-2`}>
        {total}pt
      </span>
    </span>
  );
}


type Item = {
  agent: Agent;
  pct: number;
  labelSecondary?: string;
  badge?: Selo;
};

type Props = {
  title: string;
  items: Item[];
  totalLabel: string;
  totalPct: number;
  totalSecondary?: string;
  accent?: "meta" | "leads" | "volume";
};

const accentBar: Record<string, string> = {
  meta: "from-orange-500 via-red-500 to-red-600",
  leads: "from-emerald-500 via-emerald-400 to-emerald-500",
  volume: "from-blue-500 via-cyan-400 to-blue-500",
};

export function AgentTimeline({ title, items, totalLabel, totalPct, totalSecondary, accent = "meta" }: Props) {
  const [editing, setEditing] = useState<Agent | null>(null);
  const clampedTotal = Math.max(0, Math.min(100, totalPct));

  return (
    <div className="rounded-xl border border-white/10 bg-black/40 p-5">
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-sm font-bold uppercase tracking-widest text-white/80">{title}</h4>
        <div className="text-right">
          <div className="text-[10px] uppercase tracking-widest text-white/50">{totalLabel}</div>
          <div className="text-lg font-bold text-white">
            {totalPct.toFixed(1).replace(".", ",")}%
            {totalSecondary && <span className="ml-2 text-xs font-normal text-white/60">{totalSecondary}</span>}
          </div>
        </div>
      </div>

      {/* Barra total agencia */}
      <div className="relative h-2 rounded-full bg-white/5 overflow-hidden mb-6">
        <div
          className={`h-full bg-gradient-to-r ${accentBar[accent]}`}
          style={{ width: `${clampedTotal}%` }}
        />
      </div>

      {/* Timelines individuais */}
      <div className="space-y-6">
        {items.map((it) => {
          const clamped = Math.max(0, Math.min(100, it.pct));
          const complete = it.pct >= 100;
          const negative = it.pct < 0;
          return (
            <div key={it.agent.id} className="relative">
              <div className="flex items-center justify-between text-xs text-white/60 mb-1.5">
                <span className="font-medium text-white/80 flex items-center gap-2">
                  {it.agent.nome}
                  {it.badge && <SeloBadge selo={it.badge} verde={it.agent.selos_verde ?? 0} azul={it.agent.selos_azul ?? 0} vermelho={it.agent.selos_vermelho ?? 0} />}
                </span>

                <span className="tabular-nums">
                  {it.labelSecondary && <span className="mr-2 text-white/50">{it.labelSecondary}</span>}
                  <span className={complete ? "text-emerald-400 font-bold" : negative ? "text-red-400 font-bold" : "text-white/80"}>
                    {it.pct.toFixed(1).replace(".", ",")}%
                  </span>
                </span>
              </div>
              <div className="relative h-8">
                {/* trilha */}
                <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-1.5 rounded-full bg-white/5" />
                <div
                  className={`absolute left-0 top-1/2 -translate-y-1/2 h-1.5 rounded-full bg-gradient-to-r ${accentBar[accent]}`}
                  style={{ width: `${clamped}%` }}
                />
                {/* avatar */}
                <button
                  onClick={() => setEditing(it.agent)}
                  className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 group"
                  style={{ left: `${clamped}%` }}
                  title="Editar foto / leads"
                >
                  <Avatar className={`h-9 w-9 border-2 ${complete ? "border-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.6)]" : "border-white/40 group-hover:border-white"}`}>
                    <AvatarImage src={it.agent.photo_url ?? undefined} alt={it.agent.nome} />
                    <AvatarFallback className="bg-white/10 text-white text-[10px]">
                      {it.agent.nome.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </button>
              </div>
              {/* marcações 0/50/100 */}
              <div className="flex justify-between text-[9px] uppercase tracking-wider text-white/30 mt-1">
                <span>0%</span>
                <span>50%</span>
                <span>100%</span>
              </div>
            </div>
          );
        })}
      </div>

      {editing && <AgentEditDialog agent={editing} onClose={() => setEditing(null)} />}
    </div>
  );
}
