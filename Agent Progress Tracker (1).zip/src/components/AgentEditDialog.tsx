import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";
import { updateAgent, SELO_PTS, type Agent } from "@/lib/agents";

async function fileToDataUrl(file: File): Promise<string> {
  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => {
      const im = new Image();
      im.onload = () => resolve(im);
      im.onerror = reject;
      im.src = r.result as string;
    };
    r.onerror = reject;
    r.readAsDataURL(file);
  });
  const size = 256;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  const scale = Math.max(size / img.width, size / img.height);
  const w = img.width * scale;
  const h = img.height * scale;
  ctx.drawImage(img, (size - w) / 2, (size - h) / 2, w, h);
  return canvas.toDataURL("image/jpeg", 0.85);
}

const toNum = (s: string) => {
  const n = parseFloat(s.replace(",", "."));
  return Number.isFinite(n) ? n : 0;
};
const toInt = (s: string) => Math.max(0, parseInt(s || "0", 10) || 0);

export function AgentEditDialog({ agent, onClose }: { agent: Agent; onClose: () => void }) {
  const qc = useQueryClient();
  const [photo, setPhoto] = useState<string | null>(agent.photo_url);
  const [leads, setLeads] = useState(String(agent.leads));
  const [leadsTotal, setLeadsTotal] = useState(String(agent.leads_total));
  const [aumento, setAumento] = useState(String(agent.aumento_saldo));
  const [meta, setMeta] = useState(String(agent.meta_aumento_saldo));
  const [producao, setProducao] = useState(String(agent.producao));
  const [potencial, setPotencial] = useState(String(agent.potencial_volume));
  const [sVerde, setSVerde] = useState(String(agent.selos_verde ?? 0));
  const [sAzul, setSAzul] = useState(String(agent.selos_azul ?? 0));
  const [sVerm, setSVerm] = useState(String(agent.selos_vermelho ?? 0));
  const [saving, setSaving] = useState(false);

  const totalPts =
    toInt(sVerde) * SELO_PTS.verde +
    toInt(sAzul) * SELO_PTS.azul +
    toInt(sVerm) * SELO_PTS.vermelho;

  const onPick = async (file?: File | null) => {
    if (!file) return;
    try {
      setPhoto(await fileToDataUrl(file));
    } catch {
      toast.error("Não foi possível carregar a imagem");
    }
  };

  const save = async () => {
    setSaving(true);
    try {
      await updateAgent(agent.id, {
        photo_url: photo,
        leads: toInt(leads),
        leads_total: toInt(leadsTotal),
        aumento_saldo: toNum(aumento),
        meta_aumento_saldo: toNum(meta),
        producao: toNum(producao),
        potencial_volume: toNum(potencial),
        selos_verde: toInt(sVerde),
        selos_azul: toInt(sAzul),
        selos_vermelho: toInt(sVerm),
      });
      await qc.invalidateQueries({ queryKey: ["agents"] });
      toast.success("Agente atualizado");
      onClose();
    } catch (e: any) {
      toast.error(e?.message ?? "Erro ao salvar");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{agent.nome} — {agent.agencia}</DialogTitle>
        </DialogHeader>

        <div className="space-y-5">
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              <AvatarImage src={photo ?? undefined} />
              <AvatarFallback>{agent.nome.slice(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="flex-1 space-y-2">
              <Label htmlFor="photo">Foto do agente</Label>
              <Input id="photo" type="file" accept="image/*" onChange={(e) => onPick(e.target.files?.[0])} />
              {photo && (
                <Button type="button" variant="ghost" size="sm" onClick={() => setPhoto(null)}>
                  Remover foto
                </Button>
              )}
            </div>
          </div>

          <section className="space-y-2">
            <h4 className="text-xs uppercase tracking-widest text-muted-foreground">01 · Meta de Saldo</h4>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <Label htmlFor="prod" className="text-xs">Produção (R$)</Label>
                <Input id="prod" inputMode="decimal" value={producao} onChange={(e) => setProducao(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="meta" className="text-xs">Meta (R$)</Label>
                <Input id="meta" inputMode="decimal" value={meta} onChange={(e) => setMeta(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="aum" className="text-xs">Aum. Saldo (R$)</Label>
                <Input id="aum" inputMode="decimal" value={aumento} onChange={(e) => setAumento(e.target.value)} />
              </div>
            </div>
          </section>

          <section className="space-y-2">
            <h4 className="text-xs uppercase tracking-widest text-muted-foreground">02 · Leads</h4>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="leadsTotal" className="text-xs">Leads recebidos</Label>
                <Input id="leadsTotal" type="number" min={0} value={leadsTotal} onChange={(e) => setLeadsTotal(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="leads" className="text-xs">Leads convertidos</Label>
                <Input id="leads" type="number" min={0} value={leads} onChange={(e) => setLeads(e.target.value)} />
              </div>
            </div>
            <p className="text-[10px] text-muted-foreground">% Leads = convertidos ÷ recebidos.</p>
          </section>

          <section className="space-y-2">
            <h4 className="text-xs uppercase tracking-widest text-muted-foreground">03 · Volume Captado · Selos</h4>
            <div>
              <Label htmlFor="pot" className="text-xs">Potencial (R$)</Label>
              <Input id="pot" inputMode="decimal" value={potencial} onChange={(e) => setPotencial(e.target.value)} />
            </div>
            <div className="grid grid-cols-3 gap-2 pt-1">
              <div>
                <Label htmlFor="sv" className="text-xs flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" /> Verde (5pt)
                </Label>
                <Input id="sv" type="number" min={0} value={sVerde} onChange={(e) => setSVerde(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="sa" className="text-xs flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-blue-400" /> Azul (3pt)
                </Label>
                <Input id="sa" type="number" min={0} value={sAzul} onChange={(e) => setSAzul(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="sr" className="text-xs flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-red-400" /> Vermelho (1pt)
                </Label>
                <Input id="sr" type="number" min={0} value={sVerm} onChange={(e) => setSVerm(e.target.value)} />
              </div>
            </div>
            <div className="text-[11px] rounded-md border p-2 bg-muted/40 flex items-center justify-between">
              <span className="text-muted-foreground">Total de pontos deste agente:</span>
              <span className="font-bold text-base tabular-nums">{totalPts} pt{totalPts !== 1 ? "s" : ""}</span>
            </div>
          </section>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancelar</Button>
          <Button onClick={save} disabled={saving}>{saving ? "Salvando..." : "Salvar"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
